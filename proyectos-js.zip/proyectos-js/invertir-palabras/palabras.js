palabra = "pato"
resultadoPalabra = ""

for(i = palabra.length-1; i>= 0; i--) {
    resultadoPalabra += palabra[i]
}

console.log(resultadoPalabra)